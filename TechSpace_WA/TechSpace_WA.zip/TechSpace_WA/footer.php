
<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="css/footer.css">
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

</head>
	<body>

		<!-- The content of your page would go here. -->

		<!--====================================================== Start Footer ========================================================================  -->

		<!--====================================================== Start Footer ========================================================================  -->

	<footer class="footer-distributed">

		<div class="footer-left">
			<!-- <h3>Tech<span>Space</span></h3>

			<p class="footer-links">
				<a href="#">Home</a>
				|
				<a href="#">Blog</a>
				|
				<a href="#">Reviews</a>
				|
				<a href="#">About</a>
			</p>

			<p class="footer-company-name">© 2021 TechSpace<br>Developed by Suyash Deshmukh</p> -->
		</div> 

		<div class="footer-center">
			<!-- <div>
				<i class="fa fa-map-marker"></i>
				<p><span>Dombivli</span>
					Mumbai</p>
			</div>

			<div>
				<i class="fa fa-phone"></i>
				<p>+91 9898989898</p>
			</div>
			<div>
				<i class="fa fa-envelope"></i>
				<p><a href="mailto:support@TechSpace.com">support@TechSpace.com</a></p>
			</div> -->
			<h3>Tech<span>Space</span></h3>

			<!-- <p class="footer-links">
				<a href="#">Home</a>
				|
				<a href="#">Blog</a>
				|
				<a href="#">Reviews</a>
				|
				<a href="#">About</a>
			</p><br>   -->

			<br><p class="footer-company-name">© 2021 TechSpace <br> Developed by Suyash Deshmukh & Suyash Deshmukh</p>
		</div>
		<!-- <div class="footer-right">
			<p class="footer-company-about">
				<span>About TechSpace</span>
				Techspace as name suggests provide all the technology or technical related information at one place.</p>
			<div class="footer-icons">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>
				<a href="#"><i class="fa fa-linkedin"></i></a>
				<a href="#"><i class="fa fa-youtube"></i></a>
			</div> 
		</div>  -->
	</footer>


<!--====================================================== End Footer ========================================================================  -->

		<!--====================================================== End Footer ========================================================================  -->

	</body>
</html>